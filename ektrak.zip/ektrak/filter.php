<?php 

$ambil_conf_local = file_get_contents("/etc/bind/named.conf.local");
$cari = preg_match('/'.$domain.'/i', $ambil_conf_local);
if ($cari == 1) {
	echo "\n [!] Domain $domain sudah terdaftar\n";
	$tanya = readline(" [?] cek domain yang terdaftar? y/n : ");
	if (strtolower($tanya) == 'y') {
		echo "\n    ---------!List Domain Aktive!-----------_\n";
		system("domain.txt");
	}
	die;
}

$fopen_domain = fopen('domain.txt', 'a');
				fwrite($fopen_domain, $domain."\n");
 ?>
