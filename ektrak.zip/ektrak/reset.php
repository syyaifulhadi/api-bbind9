<?php 
echo " [!] Mode Reset Aktive\n";
$domain = readline(" [?] Domain Name: ");
$ip = readline(" [?] IP Address: ");
if (empty($domain) AND empty($ip)) {
echo "
 ?? Invalit
[ HELP ]
	--help     bantuan dalam bentuk panduan
	--ip       configurasi ip dns server
	--d        configurasi domain dns server
	--reset    mengembalikan settingan menjadi awal
	--contact  mengirim pesan ke Admin melalu Email Gateway\n";die;
}

fwrite(fopen('/etc/bbind9/domain.txt', 'w'), '');
include "/etc/bbind9/conf.default.php";
include "/etc/bbind9/create.php";
system("rm /etc/bind/forward.* /etc/bind/reverse.*");
//mengunakan
create("/etc/bind/reverse.".$domain, 'w', $reverse);
create("/etc/bind/forward.".$domain, 'w', $forwoard);
create("/etc/bind/named.conf.options", 'w', $options);
create("/etc/bind/named.conf.local", 'w', $conf_local);
create("/etc/resolv.conf", 'w', $resolv);sleep(2);
system("systemctl restart bind9");
echo "\n Reset System DNS Server Successfully\n";die;
 ?>
