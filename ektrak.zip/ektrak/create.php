<?php 
function create($domain,$mode, $data){
	$fopen = fopen($domain, $mode);
	fwrite($fopen, $data);
 }
 ?>
