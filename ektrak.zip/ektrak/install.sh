sudo su
apt-get install bind9 -y
apt-get install nano -y