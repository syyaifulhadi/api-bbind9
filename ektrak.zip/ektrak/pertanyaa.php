<?php 
echo "\n";
$pilihan = readline(" [?] Pilih 1/2: ");
if ($pilihan == 2) {
	include('reset.php');die;
}
echo " [*] Tambah domain baru\n";
$domain = readline(" [?] Domain Name: ");
$ip = readline(" [?] IP Address: ");
if (empty($domain) AND empty($ip)) {
echo "
 ?? Invalit
[ HELP ]
	--help     bantuan dalam bentuk panduan
	--ip       configurasi ip dns server
	--d        configurasi domain dns server
	--reset    mengembalikan settingan menjadi awal
	--contact  mengirim pesan ke Admin melalu Email Gateway\n";die;
}
 ?>
