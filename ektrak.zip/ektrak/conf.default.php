<?php 
$forwoard = ';
; BIND data file for local loopback interface
;
$TTL	604800
@	IN	SOA	'.$domain.'. root.'.$domain.'. (
			      2		; Serial
			 604800		; Refresh
			  86400		; Retry
			2419200		; Expire
			 604800 )	; Negative Cache TTL
;
@	IN	NS	ns1.'.$domain.'.
@	IN 	NS 	ns2.'.$domain.'.
@	IN	A	'.$ip.'
ns1     IN      A       '.$ip.'
ns2     IN      A       '.$ip.'  
www	IN	CNAME	'.$domain.'.';

$reverse = ';
; BIND reverse data file for local loopback interface
;
$TTL	604800
@	IN	SOA	'.$domain.'. root.'.$domain.'. (
			      1		; Serial
			 604800		; Refresh
			  86400		; Retry
			2419200		; Expire
			 604800 )	; Negative Cache TTL
;
	IN	NS	'.$domain.'.
	IN	NS	'.$domain.'.
ns1	IN	A	'.$ip.'
ns1	IN	A	'.$ip.'
ns1	IN	A	'.$ip.'
1	IN	PTR	'.$domain.'.';
$ip_change = explode('.', $ip);
// echo $ip_change[1];
$options = 'options {
	directory "/var/cache/bind";
	forwarders {
		'.$ip.';
	 };
	dnssec-validation auto;

	#listen-on-v6 { any; };
	listen-on-v6 { none; };
	listen-on port 53 { localhost; '.$ip_change[0].'.'.$ip_change[1].'.'.$ip_change[2].'.0/24; };
	allow-query { localhost; '.$ip_change[0].'.'.$ip_change[1].'.'.$ip_change[2].'.0/24; };
	recursion yes; 
};';

$conf_local = "\n //domain baru\n".'zone "'.$domain.'" {
  type master;
    file "/etc/bind/forward.'.$domain.'";
};

zone "'.$ip_change[2].'.'.$ip_change[1].'.'.$ip_change[0].'.in-addr.arpa" {
  type master;
    file "/etc/bind/reverse.'.$domain.'";
};  ';

$resolv = "
servername $ip
search $domain";
 ?>