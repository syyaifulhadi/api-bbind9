<?php 

echo "
######################################
## Nama : Syaiful Hadi              ##
## Jurusan: TKJ                     ##
## Sch.id : SMKN 1 Bojonegoro       ##
## Tool: Auto Create DNS Server     ##
######################################\n";

 ?>